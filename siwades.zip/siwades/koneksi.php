<?php 
	$_mysqli = new mysqli("localhost","root","","siwades_db"); 
	return $_mysqli;
 ?>